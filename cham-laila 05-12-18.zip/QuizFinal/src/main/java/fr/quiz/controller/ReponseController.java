package fr.quiz.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import fr.quiz.DAO.DaoInterfaceQuiz;
import fr.quiz.beans.Question;
import fr.quiz.beans.Quiz;
import fr.quiz.beans.Reponse;

@Controller
@RequestMapping("/reponse")
public class ReponseController {
	
	@Autowired
	@Qualifier("GenericDao")
	private DaoInterfaceQuiz<Reponse> daoReponse;
	
	@Autowired
	@Qualifier("GenericDao")
	private DaoInterfaceQuiz<Question> daoQuestion;
	
	@GetMapping("/reponseSelection")
	public String selectionneReponse(Model model, String message, Reponse reponse) {
		model.addAttribute("listeQuestions", daoQuestion.findAll(Question.class));
		
		return afficheReponse(model, message, reponse);
	}
	
	@PostMapping("/new")
	public String createOrUpdateQuestion(Model model, String message, Reponse reponse, @RequestParam("choixQuestion") int id) {
		Question question = daoQuestion.findById(Question.class, id);
		System.out.println(question.getEnonce());
		reponse.setQuestion(question);
		daoReponse.createOrUpdate(reponse);
		
		model.addAttribute("listeReponse", daoReponse.findAll(Reponse.class));
		model.addAttribute("msg", "R�ponse ajout�e");
		return selectionneReponse(model, null, reponse) ;		
	}
	
	@PostMapping("/delete")
	public String deleteReponse(Model model, @RequestParam int id) {
	
			Reponse reponse = daoReponse.findById(Reponse.class, id);
			daoReponse.delete(Reponse.class, id);
					
			return afficheReponse(model, "R�ponse supprim�e : " + reponse.getEnonceReponse(), reponse);		
	}
	
	public String afficheReponse(Model model, String message, Reponse reponse ) {
		
		model.addAttribute("listeReponse", daoReponse.findAll(Reponse.class));
		model.addAttribute("msg", message);
		
	return "adminAddReponse";
		
	}
	
}