package fr.quiz.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import fr.quiz.DAO.DaoInterfaceQuiz;
import fr.quiz.beans.Question;
import fr.quiz.beans.Quiz;
import fr.quiz.beans.Reponse;

@Controller
@RequestMapping("/affiche")
public class AfficheQuizController {

	@Autowired
	private DaoInterfaceQuiz<Quiz> daoQuiz;

	@Autowired
	private DaoInterfaceQuiz<Question> daoQuestion;

	@Autowired
	private DaoInterfaceQuiz<Reponse> daoReponse;

	public DaoInterfaceQuiz<Question> getDaoQuestion() {
		return daoQuestion;
	}

	@GetMapping("/afficherQuiz")
	public String afficheQuizGet(Model model, Quiz quiz) {

		
		
		model.addAttribute("listeQuiz", daoQuiz.findAll(Quiz.class));
		return "afficheQuiz";

	}

	@PostMapping("/afficherQuestion/{numeroQuestion}")
	public String afficherQuestion(Model model, Question question, HttpSession session,
			@RequestParam("choixQuiz") Integer idQuiz, @PathVariable("numeroQuestion") Integer numeroQuestion) {

		List<Question> listeQuestion = daoQuestion.findObjectByForeignKey(Question.class, "quiz.id", idQuiz);
		Question selectedQuestion = null;

		for (Question question2 : listeQuestion) {
			if (question2.getNumeroQuestion() == numeroQuestion) {
				selectedQuestion = question2;
				break;
			}
		}

		model.addAttribute("choixQuiz", idQuiz);
		model.addAttribute("question", selectedQuestion);
		Integer idQuestion = selectedQuestion.getId();

		System.out.println("Oui il est l� " + idQuestion);

		return afficherReponse(model, session, idQuestion);

	}

	public String afficherReponse(Model model, HttpSession session, Integer idQuestion) {
		System.out.println("Oui il encore est l� " + idQuestion);
		List<Reponse> listeReponse = daoReponse.findObjectByForeignKey(Reponse.class, "question.id", idQuestion);

		model.addAttribute("listeReponse", listeReponse);

		for (Reponse reponse : listeReponse) {
			System.out.println(reponse);
		}

		System.out.println("OUi il est pass� par ici");

		return "afficheQuiz";

	}

}
