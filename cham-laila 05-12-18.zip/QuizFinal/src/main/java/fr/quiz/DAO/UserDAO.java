package fr.quiz.DAO;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import fr.quiz.beans.User;

// Transactional est une transaction vers la BDD.
@Transactional
public class UserDAO implements DaoInterfaceUser{

	@Autowired
	private SessionFactory sessionFactory;


	public UserDAO() {
		super();
	}

	public User findByEmail(String email) {
		System.out.println("salut");
		Session session = sessionFactory.getCurrentSession();
		
		TypedQuery<User> query = session.createQuery(
				"SELECT entity FROM " + User.class.getName() + " entity WHERE email = ?1",
				User.class);
		query.setParameter(1, email);
		List<User> users = query.getResultList();
		if (users.size() == 1) {
			return users.get(0);
		} else {

			return null;
		}
	}
	
	public User createOrUpdate(User user) {
		Session session = sessionFactory.getCurrentSession();

		session.persist(user);

		return user;
	}
}