package fr.quiz.DAO;

import fr.quiz.beans.User;

// On cr�e une interface sp�cifique au UserDAO
public interface DaoInterfaceUser{
	
	User findByEmail(String email);
		
	
}