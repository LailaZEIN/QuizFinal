package fr.quiz.utils;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

// m�thodes g�n�r�es automatiquement par : source/Override implements method
public class LoginInterceptor extends HandlerInterceptorAdapter {

	private List<String> ignoreList;
	

	public List<String> getIgnoreList() {
		return ignoreList;
	}


	public void setIgnoreList(List<String> ignoreList) {
		this.ignoreList = ignoreList;
	}


	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		String requesteUrl = request.getRequestURI();
		boolean urlAIgnorer = false;
		
		// l'url demand�e est-elle dans la liste des URLs � ignorer?
		for (String urlIgnoree : ignoreList) {
			
			//l'url cherch�e correspond � une url � ignorer
			if (requesteUrl.contains(urlIgnoree)) {
				urlAIgnorer = true;
				break;
			}

		}
		//si ce n'est pas une url � ignorer(typiquement/login)
		if(!urlAIgnorer) {
		Object email = request.getSession().getAttribute("email");
		
		//on n'a pas de user dans la session, donc l'utilisateur n'est pas identifi�.
		if (email == null) {
						
			//On redirige vers le controller log in
			request.getRequestDispatcher("/login").forward(request, response);

		}
		}
		return true;
	}

}
