package fr.quiz.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import fr.quiz.DAO.DaoInterfaceQuiz;
import fr.quiz.beans.Question;
import fr.quiz.beans.Quiz;

@Controller
@RequestMapping("/question")
public class QuestionController {
	
	@Autowired
	@Qualifier("GenericDao")
	private DaoInterfaceQuiz<Question> daoQuestion;
	
	@Autowired
	@Qualifier("GenericDao")
	private DaoInterfaceQuiz<Quiz> daoQuiz;
	
	
	public DaoInterfaceQuiz<Question> getDaoQuestion() {
		return daoQuestion;
	}

	public void setDaoQuestion(DaoInterfaceQuiz<Question> daoQuestion) {
		this.daoQuestion = daoQuestion;
	}

	
	@GetMapping("/quizSelection")
	public String selectionneQuiz(Model model) {
		
		model.addAttribute("listeQuiz", daoQuiz.findAll(Quiz.class));
		
		return "adminAddQuestions";
	}

	@PostMapping("/new")
	public String createOrUpdateQuestion( Model model, Question question, @RequestParam("choixQuiz") int numeroQuiz) {
		Quiz quiz = daoQuiz.findById(Quiz.class, numeroQuiz);
		question.setQuiz(quiz);
		daoQuestion.createOrUpdate(question);
		
		model.addAttribute("msg1", "Question ajout�e");
		
		return selectionneQuiz(model);
	}

	
	
}

