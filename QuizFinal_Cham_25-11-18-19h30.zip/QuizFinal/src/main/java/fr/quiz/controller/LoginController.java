package fr.quiz.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import fr.quiz.DAO.DaoInterfaceUser;
import fr.quiz.DAO.UserDAO;
import fr.quiz.beans.User;
import fr.quiz.viewModel.UserViewModel;

@Controller
public class LoginController {

	@Autowired
	@Qualifier("userDao")
	private DaoInterfaceUser userDao;

	// Avec Get, on va de l'index vers la page login pour se connecter
	@GetMapping("/login")
	public ModelAndView showLogin() {

		return new ModelAndView("login");
	}

	// Avec Post, on va entrer nos identifiant et mot de passe � travers une
	// condition d'�galit� entre eux dans notre requ�te.
	// Une fois renseign�s, on attend en retour l'affichage de notre session dans
	// l'index afin de g�rer les quiz
	@PostMapping("/login")
	public ModelAndView checkLogin(UserViewModel userFromForm, HttpSession session) {		
		// returnUrl est le lien "login" attendu en retour dans le Return � la fin de
		// notre m�thode en PostMapping
		String returnUrl = "login";

		// TODO r�cup�rer l'utilisateur qui correspond � l'email (m�thode dans userdao).
		User userFromBDD = userDao.findByEmail(userFromForm.getEmail());
		// V�rifier que cet utilisateur r�cup�r� n'est pas "null". (rajouter dans le if
		// ci-dessous).
		// v�rifier que le password qu'on va r�cup�rer du formulaire soit identique �
		// celui de l'utilisateur r�cup�r� dans userdao (rajouter dans le if ci-dessous)
		// si c'est bon �a envoie vers la page actionAction
		// rajouter un if � l'int�rieur pour d�marquer le joueur de l'admin
		if ((userFromForm.getEmail() != null) && (userFromForm.getPassword() != null) && (userFromForm.getEmail() != "")
				&& (userFromForm.getPassword() != "") && (userFromBDD != null) && (userFromForm.getPassword().equals(userFromBDD.getPassword()))) {
			session.setAttribute("user", userFromForm.getEmail());
			
			if (userFromBDD.getIsAdmin() == true) {
				returnUrl = "actionAdmin";
			} else {				
				returnUrl = "afficheQuiz";
			}
		}

		// On renvoie la page "login" que l'on souhaite afficher
		return new ModelAndView(returnUrl);
	}

}
