package fr.quiz.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import fr.quiz.DAO.DaoInterfaceQuiz;
import fr.quiz.DAO.DaoInterfaceUser;
import fr.quiz.beans.User;

@Controller
@RequestMapping("/user")
public class UserController {

		@Autowired
		@Qualifier("userDao")
		private DaoInterfaceUser daoUser;
		
		public DaoInterfaceUser getDao() {
			return daoUser;
		}
		
		public void setDao(DaoInterfaceUser dao) {
			this.daoUser = dao;
		}
		
		@GetMapping("/new")
		public String newUser() {
			
			return "user";
		}
		
		@PostMapping("/new")
		public String createOrUpdatePersonne( Model model, User user, String message) {
			
			daoUser.createOrUpdate(user);
			model.addAttribute("msg", "Inscription valid�e");
			return "user";	
		}
		
		

}
