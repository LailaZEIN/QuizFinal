package fr.quiz.DAO;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import fr.quiz.beans.User;

// Transactional est une transaction vers la BDD.
@Transactional
public class UserDAO extends GenericDAO<User> implements DaoInterfaceUser {

	@Autowired
	private SessionFactory sessionFactory;

	public User findByEmail(String email) {
		Session session = sessionFactory.getCurrentSession();
		TypedQuery<User> query = session.createQuery(
				"SELECT entity FROM " + User.class.getName() + " entity WHERE entity.email = '" + email + "'",
				User.class);
		List<User> users = query.getResultList();
		if (users.size() == 1) {
			return users.get(0);
		} else {

			return null;
		}
	}
}
