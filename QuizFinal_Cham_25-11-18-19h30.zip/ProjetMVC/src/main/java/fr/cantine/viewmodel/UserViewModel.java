package fr.cantine.viewmodel;

public class UserViewModel {
	
	private String userName;
	private String password;
	
	
	
	
	
	public UserViewModel() {
		
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	
	
	
}
