package fr.cantine.utils;

public class PasBienException extends Exception{

	public PasBienException(String message) {
		super(message);
		
	}
	
	
	
	
	
	

}
