package fr.cantine.utils;

public class Calculatrice {
	
	
	
	public int additionne(Integer a, Integer b) {
		
	
		return a + b ;
		
		
	}
	
	public Double divise(Double a, Double b) throws PasBienException {
		
		if(b==0) throw new PasBienException("C'est mal !!!!!");
		
		
		return a/b;
		
		
	}

}
