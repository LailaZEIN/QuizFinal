package fr.cantine.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/menu")
public class MenuController {
	@RequestMapping("/{menu}/Day/{day}")
	public String getMenuForDay(@PathVariable("menu") String monMenu, @PathVariable("day") String jour, Model model)
			throws Exception {

		model.addAttribute("Le_menu", monMenu);
		int [] toto = {1,32};
		int titi = toto[6];

		if (!jour.equalsIgnoreCase("lundi")) {
			model.addAttribute("Le_jour", jour);
		} else {
			throw new Exception("Nous sommes ferm�s lundi !!");
		}

		return "menu";

	}

}
