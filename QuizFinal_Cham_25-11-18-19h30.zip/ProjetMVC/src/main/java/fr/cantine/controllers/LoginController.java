package fr.cantine.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import fr.cantine.viewmodel.UserViewModel;

@Controller
public class LoginController {

	@GetMapping("/login") // on va de l'index vers la page Login
	public ModelAndView showLogin() {
		
		return new ModelAndView("login");
		
	}
	
	@PostMapping("/login")
	public ModelAndView checkLogin(UserViewModel user, HttpSession session ) {
		String returnUrl ="login";
		
		if((user.getUserName()!=null ) 
				&& (user.getPassword()!=null) 
				&& (user.getUserName()!="") 
				&& (user.getPassword()!="")
				&& (user.getUserName().equals(user.getPassword()))) {
			session.setAttribute("user", user.getUserName());
			
			returnUrl ="redirect:/carte";
						
		}
				
		return new ModelAndView(returnUrl); // on retourne le nom de la page qu'on veut afficher
	} 
	
}
