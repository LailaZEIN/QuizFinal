package fr.cantine.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import fr.cantine.beans.Plat;
import fr.cantine.dao.DaoInterface;

@Controller
@RequestMapping("/plat")
public class PlatController {

	@Autowired
	private DaoInterface<Plat> dao;
	
	@Autowired
	private MessageSource messageSource;
	

	public DaoInterface<Plat> getDao() {
		return dao;
	}

	public void setDao(DaoInterface<Plat> dao) {
		this.dao = dao;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	@GetMapping("/new")
	public String afficherAjouterPlat() {

		return "newPlat";
	}

//	@PostMapping("/new")
//	public String ajouterPlat(Model model, 
//			@RequestParam String nom, // nom dans les input du form
//			@RequestParam double prix, 
//			@RequestParam TypePlat typePlat
//			) {
//			
//		System.out.println(nom +","+ prix+","+typePlat);
//		
//		Plat plat = new Plat();
//		plat.setNom(nom);
//		plat.setPrix(prix);
//		plat.setTypePlat(typePlat);
//		
//		dao.createOrUpdate(plat);
//		
//		model.addAttribute("listePlats",dao.findAll());
//		model.addAttribute("msg", "Nouveau plat ajout� : "+plat.toString());
//	
//		return "carte";
//	}

	@PostMapping("/new")
	public String ajouterPlat(Model model, Plat plat) {

		System.out.println(plat);
		dao.createOrUpdate(plat);

		return afficheCrate(model, "Nouveau plat ajout� : " + plat.toString());

	}

	@PostMapping("/delete")
	public String supprimerPlat(Model model, @RequestParam Long id) {

		Plat plat = dao.findById(id);
		dao.delete(id);

		return afficheCrate(model, "Plat supprim� : " + plat.getNom());
	}

	@PostMapping("/upload")
	public String ajoutImage(Model model,Locale locale, HttpServletRequest request, @RequestParam("image_plat") MultipartFile file,
			@RequestParam("id") long id) {
		String path = request.getServletContext().getRealPath("uploaded");

		System.out.println(path);
		File directory = new File(path); // Endroit o� on va �crire
		if (!directory.exists()) {
			directory.mkdirs();
		}
		try {
			File fichierDestination = new File(directory, new Date().getTime() + "_" + file.getOriginalFilename());
			FileOutputStream stream = new FileOutputStream(fichierDestination);
			stream.write(file.getBytes());
			stream.close();

			Plat plat = dao.findById(id);
			plat.setImage(fichierDestination.getName());
			dao.createOrUpdate(plat);

			//return afficheCrate(model, "Fichier t�l�charg� : " + fichierDestination.getName());
			return afficheCrate(model, messageSource.getMessage("T_UPLOAD_SUCCESS",new String[] {fichierDestination.getName() , new Date().toString()}, locale));
			
		} catch (Exception ex) {

		}

		return afficheCrate(model, messageSource.getMessage("T_UPLOAD_ERROR",null, locale));
	}

	private String afficheCrate(Model model, String message) {

		model.addAttribute("listePlats", dao.findAll());
		model.addAttribute("msg", message);

		return "carte";

	}
}
