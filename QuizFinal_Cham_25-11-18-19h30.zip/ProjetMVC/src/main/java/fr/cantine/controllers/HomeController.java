package fr.cantine.controllers;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

	 @RequestMapping(path={"/accueil","/default"}, method=RequestMethod.GET) //Accepte les deux m�thodes GET et POST
	//@GetMapping({"/accueil","/default"})
	public String HomePage() throws Exception {
		 //throw new Exception("C'est tr�s mal");
		return "home";
	}

	@PostMapping(value="/accueil",params= {"dateReouverture", "lieu"})
	public String HomeEnPost(Model model,
			@RequestParam String lieu,
			@DateTimeFormat(iso=ISO.DATE)
			@RequestParam Date dateReouverture) {
		model.addAttribute("dateDeReouverture", dateReouverture);
		model.addAttribute("lieu",lieu);
		return "homePost";
	}

}
