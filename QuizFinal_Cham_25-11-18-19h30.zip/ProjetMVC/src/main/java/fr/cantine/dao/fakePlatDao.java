package fr.cantine.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import fr.cantine.beans.Plat;

public class fakePlatDao<T> implements DaoInterface<Plat> {

	private Map<Long, Plat> tousLesPlatsDisponibles;
	private static long lastId = 0;

	@Override
	public Plat createOrUpdate(Plat item) {
		
		lastId++;
		item.setId(lastId);
		tousLesPlatsDisponibles.put(lastId, item);
		return null;
	}

	@Override
	public Plat findById(Long id) {
		return tousLesPlatsDisponibles.get(id);

	}

	@Override
	public List<Plat> findAll() {

		return new ArrayList<Plat>(tousLesPlatsDisponibles.values());
	}

	@Override
	public void delete(Long id) {

		tousLesPlatsDisponibles.remove(id);

	}

	public Map<Long, Plat> getTousLesPlatsDisponibles() {
		return tousLesPlatsDisponibles;
	}

	public void setTousLesPlatsDisponibles(Map<Long, Plat> tousLesPlatsDisponibles) {
		this.tousLesPlatsDisponibles = tousLesPlatsDisponibles;
	}

	public void init() {
		lastId=(long) tousLesPlatsDisponibles.values().size();
	}
	
}
