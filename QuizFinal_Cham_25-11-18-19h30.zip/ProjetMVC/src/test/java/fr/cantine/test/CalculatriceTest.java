package fr.cantine.test;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import fr.cantine.utils.Calculatrice;
import fr.cantine.utils.PasBienException;

public class CalculatriceTest {

	private static Calculatrice calc;
	// on peut changer le nom des methodes

	// setUpBeforeClass s'execute avant chaque m�thode
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		System.out.println("@BeforeClass");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterClass");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("@Before");
		calc = new Calculatrice();
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("@After");
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

	@Test
	public void additionneTest() {

		// On commence le test
		Assert.assertEquals(8, calc.additionne(3, 5));
		Assert.assertEquals(27, calc.additionne(30, -3));
	}

	@Test
	public void diviseTest() throws PasBienException {
		Double result = calc.divise(10d, 2d);
		Assert.assertNotNull(result);
	}

	@Test(expected = NullPointerException.class)
	public void additionneNullTest() {
		Assert.assertEquals(30, calc.additionne(30, 0));
	}

	@Test(expected = PasBienException.class)
	public void divisePar0Test() throws PasBienException {
		
		calc.divise(3d, 3d);
	}
}
